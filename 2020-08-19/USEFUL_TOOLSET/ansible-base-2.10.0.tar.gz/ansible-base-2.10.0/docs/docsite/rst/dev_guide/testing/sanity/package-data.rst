package-data
============

Verifies that the combination of ``MANIFEST.in`` and ``package_data`` from ``setup.py``
properly installs data files from within ``lib/ansible``
