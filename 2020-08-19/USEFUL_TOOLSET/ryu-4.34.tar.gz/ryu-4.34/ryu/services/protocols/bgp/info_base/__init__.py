"""
 Package for Information Base of various kind and for different afi/safi.
"""
