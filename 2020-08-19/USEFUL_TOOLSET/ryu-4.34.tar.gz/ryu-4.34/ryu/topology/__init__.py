"""
Switch and link discovery module. Planned to replace ryu/controller/dpset.
"""
